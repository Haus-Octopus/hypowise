import json

def calculate_loan_repayment(loan_amount, annual_interest_rate, monthly_payment, start_year, start_month, term_years, annual_repayment):
    monthly_interest_rate = annual_interest_rate / 12 / 100
    current_year, current_month = start_year, start_month
    total_interest_paid = 0
    payments_list = []

    # Calculate the total number of payments
    total_months = term_years * 12

    month_count = 0
    while loan_amount > 0 and month_count < total_months:
        month_count += 1
        if current_month > 12:
            current_month = 1
            current_year += 1

        # Check if it's the month for annual repayment
        is_annual_payment_month = (current_month == 4 and month_count > 12)
        monthly_repayment = monthly_payment + (annual_repayment if is_annual_payment_month else 0)

        # Calculate interest and principal paid
        interest_paid = loan_amount * monthly_interest_rate
        principal_paid = min(monthly_repayment - interest_paid, loan_amount)
        loan_amount -= principal_paid
        total_interest_paid += interest_paid

        # Record the payment details
        payments_list.append({
            "year": current_year,
            "month": current_month,
            "payment": round(monthly_repayment, 2),
            "interest_paid": round(interest_paid, 2),
            "principal_paid": round(principal_paid, 2),
            "remaining_balance": round(loan_amount, 2)
        })

        current_month += 1

    return payments_list, total_interest_paid

def lambda_handler(event, context):
    try:
        # Assuming the body of the event is a JSON string and parse it
        data = json.loads(event.get('body', '{}'))

        # Extract loan details from data
        loan_amount = float(data['loanAmount'])
        annual_interest_rate = float(data['annualInterestRate'])
        monthly_payment = float(data['monthlyPayment'])
        start_year = int(data['startYear'])
        start_month = int(data['startMonth'])
        term_years = int(data['term'])
        annual_repayment = float(data['annualRepayment'])

        # Calculate the repayment schedule
        payments, total_interest_paid = calculate_loan_repayment(
            loan_amount, annual_interest_rate, monthly_payment,
            start_year, start_month, term_years, annual_repayment
        )

        # Prepare the response body
        response_body = {
            "Processed": True,
            "Details": {
                "payments": payments,
                "totalInterestPaid": total_interest_paid
            }
        }

        return {
            "statusCode": 200,
            "body": json.dumps(response_body),
            "headers": {"Content-Type": "application/json"}
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
            "headers": {"Content-Type": "application/json"}
        }

